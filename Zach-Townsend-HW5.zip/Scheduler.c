#include <stdlib.h>
#include <stdio.h>
#include <string.h>


struct Instruction {
    int processID;
    int arrivalTime;
    int burstDuration;
    int priority;
};

struct Instruction parseInstruction(char* line) {
    struct Instruction newInstruction;
    newInstruction.processID = atoi(strtok(line, ","));
    newInstruction.arrivalTime = atoi(strtok(NULL, ","));
    newInstruction.burstDuration = atoi(strtok(NULL, ","));
    newInstruction.priority = atoi(strtok(NULL, ","));
    return newInstruction;
}

char* instructionAsText(struct Instruction instruction) {
    char* text = malloc(100 * sizeof(char));
    sprintf(text, "Process ID: %d\nArrival time: %d\nBurst duration: %d\nPriority: %d\n", instruction.processID, instruction.arrivalTime, instruction.burstDuration, instruction.priority);
    return text;
}


int main(int argCount, char** args) {
    if (argCount == 1) {
        printf("Error: must provide at least one instruction");
        return 1;
    }
    struct Instruction instruction = parseInstruction(args[1]);
    printf(instructionAsText(instruction));
}